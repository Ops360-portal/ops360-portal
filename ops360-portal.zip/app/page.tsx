
import Dashboard from './(dashboard)/page';

export default function Home() {
  return <Dashboard />;
}
